
-- open and set default database handle
config.db = {
  engine='postgresql',
  dbname='webmcp_demo'
}

listen{
  { proto = "tcp", host = "::1", port = 8080 },
  { proto = "tcp", host = "127.0.0.1", port = 8080 },
  { proto = "interval", delay = 60, handler = function() io.stderr:write("Background job executed here\n") end }
}

-- 'request.get_relative_baseurl()' should be replaced by the absolute
-- base URL of the application, as otherwise HTTP redirects will not be
-- standard compliant
--request.set_absolute_baseurl(request.get_relative_baseurl())

-- uncomment the following lines, if you want to use a database driven
-- tempstore instead of a file-based tempstore (for flash messages):
--
-- function tempstore.save(blob)
--   return Tempstore:create(blob)
-- end
-- function tempstore.pop(key)
--   return Tempstore:data_by_key(key)
-- end

