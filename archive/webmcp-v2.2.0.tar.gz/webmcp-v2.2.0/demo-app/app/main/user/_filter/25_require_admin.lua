app.session.user:require_privilege("admin")

execute.inner()
