slot.put_into('title', encode.html(_"webmcp demo application"))

slot.put_into('main', encode.html(_"Welcome to webmcp demo application"))
