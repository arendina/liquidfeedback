request.for_each(function()
  charset._current = "UTF-8"
end)
