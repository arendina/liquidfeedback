charset.data.utf_8 = {
  special_chars = {
    nobreak_space  = "\194\160",
    minus_sign     = "\226\136\146",
    inf_sign       = "\226\136\158",
    hyphen_sign    = "\226\128\144",
    nobreak_hyphen = "\226\128\145",
    figure_dash    = "\226\128\146",
  },
}
