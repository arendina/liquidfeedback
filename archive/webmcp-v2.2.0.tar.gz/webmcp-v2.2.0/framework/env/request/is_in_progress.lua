--[[--
bool =                    -- true, if a request is currently in progress (i.e. being answered)
request.is_in_progress()

This function can be used to check if a request is currently in progress. Returns false during configuration.

--]]--

function request.is_in_progress()
  return request._in_progress
end
