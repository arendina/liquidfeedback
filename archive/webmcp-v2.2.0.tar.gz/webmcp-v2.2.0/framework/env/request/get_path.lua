--[[--
path =
request.get_path()

Returns the path in the URL of the request without the leading slash and without the query part.
May return nil for a HTTP OPTIONS request with "*" target.

--]]--

function request.get_path()
  return request._http_request.path
end
