-- load moonhash library on demand
moonhash = require "moonhash"
