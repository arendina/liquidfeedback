function parse.timestamp(str, dest_type, options)
  error("Not implemented.")  -- TODO
end
