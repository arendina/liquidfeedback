execute._wrap_stack = {}
execute._finalizers = {}
