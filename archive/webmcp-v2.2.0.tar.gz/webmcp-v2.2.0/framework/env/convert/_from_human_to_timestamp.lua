function convert._from_human_to_timestamp(str)
  return atom.timestamp:load(str)
end
