function convert._from_human_to_string(str)
  return atom.string:load(str)
end
