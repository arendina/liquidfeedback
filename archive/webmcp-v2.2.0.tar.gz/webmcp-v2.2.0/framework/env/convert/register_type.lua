function convert.register_type(typ, name)
  convert._type_symbol_mappings[typ] = name
end
