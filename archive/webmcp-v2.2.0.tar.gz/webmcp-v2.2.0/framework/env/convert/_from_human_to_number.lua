function convert._from_human_to_number(str)
  return atom.number:load(str)
end
