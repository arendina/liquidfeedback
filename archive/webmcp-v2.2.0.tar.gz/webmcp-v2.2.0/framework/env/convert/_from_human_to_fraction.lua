function convert._from_human_to_fraction(str)
  return atom.fraction:load(str)
end
