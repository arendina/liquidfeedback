function convert._from_human_to_integer(str)
  return atom.integer:load(str)
end
