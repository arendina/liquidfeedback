function convert._from_human_to_date(str)
  return atom.date:load(str)
end
