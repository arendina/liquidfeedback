function convert._from_human_to_boolean(str)
  return atom.boolean:load(str)
end
