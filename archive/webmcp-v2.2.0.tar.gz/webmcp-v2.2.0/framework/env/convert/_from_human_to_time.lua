function convert._from_human_to_time(str)
  return atom.time:load(str)
end
