net._mail_config = {
  command = { "/usr/sbin/sendmail", "-t", "-i" },
  envelope_from_option = "-f"
}
