--[[--
bool =                -- set to true if layout has been set explicitly during processing request
slot.layout_is_set()

Returns true if slot.set_layout(...) has been called during handling of a request.

--]]--

function slot.layout_is_set()
  return slot._layout_set
end
