request.for_each(function()

  slot._active_slot = "default"

  slot._current_layout = "default"
  slot._content_type = nil
  slot._layout_set = false

  slot._data = nil
  slot.reset_all()

end)
