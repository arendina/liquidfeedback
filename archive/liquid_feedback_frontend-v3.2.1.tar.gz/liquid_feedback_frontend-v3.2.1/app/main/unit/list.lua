ui.title(_"Unit list")

ui.section( function()
  ui.sectionRow( function()
    execute.view{ module = "unit", view = "_list" }
  end)
end )



