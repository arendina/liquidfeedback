app.session.authority = nil
app.session.authority_uid = nil
app.session.authority_login = nil
app.session:save()

return true