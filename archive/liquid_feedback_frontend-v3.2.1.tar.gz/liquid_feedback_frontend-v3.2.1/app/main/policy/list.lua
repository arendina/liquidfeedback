ui.title(_"Policies")

execute.view { module = "policy", view = "_list" }