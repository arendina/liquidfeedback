-- Lua library path for C modules for mldap
package.cpath = WEBMCP_BASE_PATH .. "lib/mldap/?.so" .. ";" .. package.cpath