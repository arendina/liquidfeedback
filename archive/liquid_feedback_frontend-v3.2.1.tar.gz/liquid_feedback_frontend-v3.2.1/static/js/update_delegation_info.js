function updateDelegationInfo() {
  var form = document.getElementById("delegationForm");
  form.preview.value = "1";
  form.submit();
}