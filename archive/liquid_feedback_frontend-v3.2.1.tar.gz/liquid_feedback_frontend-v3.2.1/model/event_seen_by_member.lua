EventSeenByMember = mondelefant.new_class()
EventSeenByMember.table = 'event_seen_by_member'
