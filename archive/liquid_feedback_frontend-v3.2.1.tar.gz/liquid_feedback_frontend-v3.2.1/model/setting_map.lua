SettingMap = mondelefant.new_class()
SettingMap.table = 'setting_map'
SettingMap.primary_key = { "key", "subkey" }