NotificationEventSent = mondelefant.new_class()
NotificationEventSent.table = 'notification_event_sent'
