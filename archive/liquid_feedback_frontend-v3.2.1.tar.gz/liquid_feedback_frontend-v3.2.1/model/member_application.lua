MemberApplication = mondelefant.new_class()
MemberApplication.table = 'member_application'
