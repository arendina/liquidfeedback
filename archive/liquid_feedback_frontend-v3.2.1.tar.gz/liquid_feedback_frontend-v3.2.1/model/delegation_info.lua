DelegationInfo = mondelefant.new_class()
