MemberHistory = mondelefant.new_class()
MemberHistory.table = 'member_history'
